//Name		:	Dinesh Suthar
//regNo	:	2022ca108
//Aim		:	plot a graph of quickSort 
// C code to implement quicksort

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

// Function to swap two elements
void swap(int* a, int* b)
{
	int t = *a;
	*a = *b;
	*b = t;
}

// Partition the array using the last element as the pivot
int partition(long int arr[], int low, int high)
{
	// Choosing the pivot
	int pivot = arr[high];

	// Index of smaller element and indicates
	// the right position of pivot found so far
	int i = (low - 1);
	int j = low;
	for (j = low; j <= high - 1; j++) {

		// If current element is smaller than the pivot
		if (arr[j] < pivot) {

			// Increment index of smaller element
			i++;
			long int t = arr[i];
			arr[i] = arr[j];
			arr[j] = t;
		}
	}
	long int t = arr[i+1];
	arr[i+1] = arr[high];
	arr[high] = t;
	return (i + 1);
}

// The main function that implements QuickSort
// arr[] --> Array to be sorted,
// low --> Starting index,
// high --> Ending index
void quickSort(long int arr[], int low, int high)
{
	if (low < high) {

		// pi is partitioning index, arr[p]
		// is now at right place
		int pi = partition(arr, low, high);

		// Separately sort elements before
		// partition and after partition
		quickSort(arr, low, pi - 1);
		quickSort(arr, pi + 1, high);
	}
}

// Driver code
int main()
{
	long int n = 10000;
    int it = 0;
  
    // Arrays to store time duration
    // of sorting algorithms
    double tim1[10], tim2[10], tim3[10];
  
    printf("A_size, Best, Avg, Worst\n");
  
    // Performs 10 iterations
    while (it++ < 10) {
        long int a[n], b[n], c[n];
  
        // generating n random numbers
        // storing them in arrays a, b, c
        int i = 0;
        for (i = 0; i < n; i++) {
            long int no = rand() % n + 1;
            a[i] = no;
            b[i] = no;
            c[i] = no;
        }
  
        // using clock_t to store time
        clock_t start, end;
  
        // Bubble sort
        start = clock();
        quickSort(a, 0, n-1);
        end = clock();
  
        tim1[it] = ((double)(end - start));
  
        // Insertion sort
        start = clock();
        quickSort(b, 0,n-1);
        end = clock();
  
        tim2[it] = ((double)(end - start));
  
         qsort(c, n, sizeof(int), cmpfunc);
        start = clock();
        quickSort(c, 0,n-1);
        end = clock();
  
        tim3[it] = ((double)(end - start));
  
        // type conversion to long int
        // for plotting graph with integer values
        printf("%li, %li, %li, %li\n",
               n,
               (long int)tim1[it],
               (long int)tim2[it],
               (long int)tim3[it]);
  
        // increases the size of array by 10000
        n += 10000;
    }
  
    return 0;
}
