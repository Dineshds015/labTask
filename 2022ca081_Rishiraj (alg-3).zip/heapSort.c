//Name		:	RishiRaj Patel
//regNo	:	2022ca081
//Obj.		:	plot a graph of heapSort 

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int cmpfunc (const void * a, const void * b) {
   return ( *(int*)a - *(int*)b );
}

// Function to swap the position of two elements

void swap(int* a, int* b)
{

	int temp = *a;
	*a = *b;
	*b = temp;
}

// To heapify a subtree rooted with node i
// which is an index in arr[].
// n is size of heap
void heapify(long int arr[], int N, int i)
{
	// Find largest among root,
	// left child and right child

	// Initialize largest as root
	int largest = i;

	// left = 2*i + 1
	int left = 2 * i + 1;

	// right = 2*i + 2
	int right = 2 * i + 2;

	// If left child is larger than root
	if (left < N && arr[left] > arr[largest])

		largest = left;

	// If right child is larger than largest
	// so far
	if (right < N && arr[right] > arr[largest])

		largest = right;

	// Swap and continue heapifying
	// if root is not largest
	// If largest is not root
	if (largest != i) {
		long int t = arr[i];
		arr[i] = arr[largest];
		arr[largest] = t;
		//swap(&arr[i], &arr[largest]);

		// Recursively heapify the affected
		// sub-tree
		heapify(arr, N, largest);
	}
}

// Main function to do heap sort
void heapSort(long int arr[], int N)
{

	// Build max heap
	int i = N / 2;
	for (i = N / 2 - 1; i >= 0; i--)

		heapify(arr, N, i);

	// Heap sort
	for (i = N - 1; i >= 0; i--) {
		long int t = arr[0];
		arr[0] = arr[i];
		arr[i] = t;
		//swap(&arr[0], &arr[i]);

		// Heapify root element
		// to get highest element at
		// root again
		heapify(arr, i, 0);
	}
}

// A utility function to print array of size n
void printArray(int arr[], int N)
{
	int i = 0;
	for (i = 0; i < N; i++)
		printf("%d ", arr[i]);
	printf("\n");
}

// Driver's code
int main()
{
		long int n = 10000;
    int it = 0;
  
    // Arrays to store time duration
    // of sorting algorithms
    double tim1[10], tim2[10], tim3[10];
  
    printf("A_size, Best, Avg, Worst\n");
  
    // Performs 10 iterations
    while (it++ < 10) {
        long int a[n], b[n], c[n];
  
        // generating n random numbers
        // storing them in arrays a, b, c
        int i = 0;
        for (i = 0; i < n; i++) {
            long int no = rand() % n + 1;
            a[i] = no;
            b[i] = no;
            c[i] = no;
        }
  
        // using clock_t to store time
        clock_t start, end;
  
        // Bubble sort
        start = clock();
        heapSort(a, n);
        end = clock();
  
        tim1[it] = ((double)(end - start));
  
        // Insertion sort
        start = clock();
        heapSort(b, n);
        end = clock();
  
        tim2[it] = ((double)(end - start));
  
         qsort(c, n, sizeof(int), cmpfunc);
        start = clock();
        heapSort(c, n);
        end = clock();
  
        tim3[it] = ((double)(end - start));
  
        // type conversion to long int
        // for plotting graph with integer values
        printf("%li, %li, %li, %li\n",
               n,
               (long int)tim1[it],
               (long int)tim2[it],
               (long int)tim3[it]);
  
        // increases the size of array by 10000
        n += 10000;
    }
  
    return 0;
}
// This code is contributed by _i_plus_plus_.

